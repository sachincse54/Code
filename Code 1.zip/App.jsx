import React from "react";
import CommonTable from "./CommonTable";
import { Edit, Delete, CheckCircle, Cancel, Info } from "@mui/icons-material";
import { IconButton } from "@mui/material";

const handleIconClick = (row, columnKey) => {
  console.log(`Icon clicked for ${columnKey} in row ID: ${row.id}`);
};

const headers = [
  { label: "ID", key: "id" },
  { label: "Name", key: "name" },
  { label: "Email", key: "email" },
  { label: "Role", key: "role" },
  { label: "Active", key: "isActive", displayCheckbox: true }, // ✅ Boolean as Checkbox
  {
    label: "Status",
    key: "status",
    displayLikeButton: true, // 👍 Show Like button if condition matches
    matchValue: "Approved",
    apiStyleColumn: "statusStyles",
  },
  { label: "Department", key: "department" },
  { label: "Location", key: "location" },
  {
    label: "Verified",
    key: "verified",
    displayIcon: true, // 🔘 Show icons instead of text
    icons: {
      true: <CheckCircle color="success" />,
      false: <Cancel color="error" />,
    },
    onIconClick: handleIconClick, // Click event for icons
  },
  { label: "Created At", key: "createdAt" },
];

const rows = [
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 1,
    name: "Alice",
    email: "alice@example.com",
    role: "Admin",
    isActive: true, // ✅ Shows a checked checkbox
    status: "Approved", // 👍 Shows Like button
    statusStyles: { backgroundColor: "green", color: "white" }, // Styles for Like button
    department: "Engineering",
    location: "New York",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-03-01",
  },
  {
    id: 2,
    name: "Bob",
    email: "bob@example.com",
    role: "Editor",
    isActive: false, // ❌ Unchecked checkbox
    status: "Pending", // ❌ Normal text
    statusStyles: { backgroundColor: "gray", color: "white" },
    department: "Marketing",
    location: "San Francisco",
    verified: false, // 🔘 Shows error icon
    createdAt: "2024-02-20",
  },
  {
    id: 3,
    name: "Charlie",
    email: "charlie@example.com",
    role: "User",
    isActive: true, // ✅ Checked checkbox
    status: "Rejected", // ❌ Normal text
    statusStyles: { backgroundColor: "red", color: "white" },
    department: "Sales",
    location: "Los Angeles",
    verified: true, // 🔘 Shows success icon
    createdAt: "2024-01-15",
  },
  {
    id: 4,
    name: "David",
    email: "david@example.com",
    role: "Moderator",
    isActive: true,
    status: "Approved",
    statusStyles: { backgroundColor: "green", color: "white" },
    department: "HR",
    location: "Chicago",
    verified: false,
    createdAt: "2024-01-10",
  },
];

const actionButtons = [
  { icon: <Edit />, color: "primary", actionType: "edit" },
  { icon: <Delete />, color: "secondary", actionType: "delete" },
];

const handleActionClick = (action, row) => {
  console.log(`Action: ${action.actionType}, Row ID: ${row.id}`);
};

const filterButtons = [
  { label: "Approved", value: "Approved" },
  { label: "Show Inactive", value: "Inactive" },
  { label: "Show Pending", value: "Pending" },
];

const App = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Dynamic Table Example</h2>
      <CommonTable
        headers={headers}
        rows={rows}
        actionButtons={actionButtons}
        onActionClick={handleActionClick}
        enablePagination={true} // Set to false if you want to disable pagination
        defaultRowsPerPage={2}
        filterButtons={filterButtons}
      />
    </div>
  );
};

export default App;
