import React, { useState, useCallback } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Paper,
  Checkbox,
  TextField,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import { ArrowUpward, ArrowDownward } from "@mui/icons-material";
import { get } from "lodash";


const StyledTableContainer = styled(TableContainer)`
  max-height: 500px;
  border-radius: 0px;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  overflow: auto;
`;

const StyledTable = styled(Table)`
  min-width: 800px;
  background: #fff;
`;

const StyledTableHead = styled(TableHead)`
  background: linear-gradient(135deg, #1976d2, #0d47a1);
`;
const StyledTableHeadRow = styled(TablePagination)`
  background: linear-gradient(135deg, #1976d2, #0d47a1);
`;
const StyledTableHeadCell = styled(TableCell)`
  padding: 12px;
  font-weight: bold;
  color: white !important;
  text-transform: uppercase;
  cursor: pointer;
  background: blue;
`;

const StyledBodyCell = styled(TableCell)`
  padding: 14px;
  font-size: 14px;
  color: #333;
  background-color: transparent;
`;

const StyledTableRow = styled(TableRow)`
  &:hover {
    background: rgba(33, 150, 243, 0.1) !important;
  }
`;

const PaginationContainer = styled("div")`
  display: flex;
  justify-content: flex-end;
  padding: 8px;
  background: #f9f9f9;
  border-bottom-left-radius: 12px;
  border-bottom-right-radius: 12px;
`;

const SearchContainer = styled("div")`
  display: flex;
  justify-content: flex-end;
  padding: 8px;
  background: #f9f9f9;
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
`;

const CommonTable = ({
  headers,
  rows,
  actionButtons,
  onActionClick,
  enablePagination = true,
  defaultRowsPerPage = 5,
  filterButtons = [],
  
}) => {
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(defaultRowsPerPage);
  const [rowsPerPageOptions] = useState([5, 10, 25, 50, 100]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState(null);

  const getUniqueRowsPerPageOptions = useCallback(() => {
    const options = rowsPerPageOptions?.length
      ? rowsPerPageOptions
      : [5, 10, 25]; // Default list if not provided
    return [...new Set([defaultRowsPerPage, ...options])].sort((a, b) => a - b);
  }, [defaultRowsPerPage, rowsPerPageOptions]);

  const handleFilterClick = (filterValue) => {
    console.log(filterValue)
    setActiveFilter(filterValue === activeFilter ? null : filterValue);
    setSearchQuery(filterValue.toLowerCase());
    setPage(0);
  };

  const uniqueRowsPerPageOptions = getUniqueRowsPerPageOptions();

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (_, newPage) => setPage(newPage);
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value.toLowerCase());
    setPage(0);
  };

  const filteredRows = rows.filter((row) =>
    headers.some((header) =>
      row[header.key]?.toString().toLowerCase().includes(searchQuery)
    )
  );

  const sortedRows = [...filteredRows].sort((a, b) => {
    if (orderBy) {
      return order === "asc"
        ? a[orderBy] < b[orderBy]
          ? -1
          : 1
        : a[orderBy] < b[orderBy]
        ? 1
        : -1;
    }
    return 0;
  });

  const displayedRows = enablePagination
    ? sortedRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
    : sortedRows;

  return (
    <Paper elevation={3} style={{ borderRadius: "12px", overflow: "hidden" }}>
      <SearchContainer style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
        <button
              onClick={() => handleFilterClick('')}
              style={{
                marginRight: "8px",
                padding: "6px 12px",
                borderRadius: "4px",
                border: "1px solid #1976d2",
                background: activeFilter === null ? "#1976d2" : "white",
                color: activeFilter === null ? "white" : "#1976d2",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              All
            </button>
          {filterButtons.map(({ label, value }, index) => (
            <button
              key={index}
              onClick={() => handleFilterClick(value)}
              style={{
                marginRight: "8px",
                padding: "6px 12px",
                borderRadius: "4px",
                border: "1px solid #1976d2",
                background: activeFilter === value ? "#1976d2" : "white",
                color: activeFilter === value ? "white" : "#1976d2",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              {label}
            </button>
          ))}
        </div>

        <TextField
          variant="outlined"
          size="small"
          placeholder="Search..."
          onChange={handleSearch}
        />
      </SearchContainer>
      <StyledTableContainer>
        <StyledTable stickyHeader>
          <StyledTableHead>
            <TableRow>
              {headers.map((header) => (
                <StyledTableHeadCell
                  key={header.key}
                  onClick={() => handleRequestSort(header.key)}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    <span>{header.label}</span>
                    {orderBy === header.key ? (
                      order === "asc" ? (
                        <ArrowUpward fontSize="small" />
                      ) : (
                        <ArrowDownward fontSize="small" />
                      )
                    ) : null}
                  </div>
                </StyledTableHeadCell>
              ))}
              <StyledTableHeadCell style={{ textAlign: "center" }}>
                Actions
              </StyledTableHeadCell>
            </TableRow>
          </StyledTableHead>
          <TableBody>
            {displayedRows?.length > 0 ? (
displayedRows.map((row, index) => (
    <StyledTableRow hover key={index}>
      {headers.map((header) => (
        <StyledBodyCell key={header.key}>
          {header.displayCheckbox ? (
            <Checkbox checked={row[header.key]} disabled />
          ) : header.displayIcon ? (
            <IconButton
              onClick={() => header.onIconClick?.(row, header.key)}
            >
              {header.icons[row[header.key]] || null}
            </IconButton>
          ) : header.displayLikeButton &&
            row[header.key] === header.matchValue ? (
            <IconButton style={row[header.apiStyleColumn]}>
              👍
            </IconButton>
          ) : (
            row[header.key]
          )}
        </StyledBodyCell>
      ))}
      <StyledBodyCell>
        {actionButtons.map((action, idx) => (
          <IconButton
            key={idx}
            onClick={() => onActionClick(action, row)}
            color={action.color || "primary"}
          >
            {action.icon}
          </IconButton>
        ))}
      </StyledBodyCell>
    </StyledTableRow>
  ))
            )
        :
        (
<TableRow>
      <TableCell colSpan={headers.length + 1} align="center">
        No data found
      </TableCell>
    </TableRow>
        )}
            {}
          </TableBody>
        </StyledTable>
      </StyledTableContainer>
      {enablePagination && (
        <PaginationContainer>
          <TablePagination
            rowsPerPageOptions={uniqueRowsPerPageOptions}
            component="div"
            count={filteredRows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </PaginationContainer>
      )}
    </Paper>
  );
};

export default CommonTable;
