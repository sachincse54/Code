import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  Paper,
} from "@mui/material";
import { styled, ThemeProvider, createTheme } from "@mui/material/styles";

// Styled Components
const StyledTableContainer = styled(TableContainer)`
  max-height: 500px;
  border-radius: 8px;
  box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`;

const StyledTable = styled(Table)`
  min-width: 800px;
  background: #fff;
`;

const StyledTableHead = styled(TableHead)`
  ${({ headerStyles }) => `
    background: ${'black' || "#2196f3"};
  `}
`;

const StyledTableCell = styled(TableCell)`
  padding: 6px;
  font-weight: 600;
  color: ${({ headerStyles }) => headerStyles?.color || "#ffffff"};
  text-transform: uppercase;
`;

const StyledBodyCell = styled(TableCell)`
  padding: 6px;
  font-size: 14px;
  color: #333;
  background-color: #fafafa;
  &:hover {
    background-color: rgba(33, 150, 243, 0.1);
  }
`;

const ActionsColumn = styled(TableCell)`
  min-width: 120px;
  text-align: center;
`;

const PaginationContainer = styled("div")`
  display: flex;
  justify-content: flex-end;
  padding: 4px;
  background: #f9f9f9;
`;

const CommonTable = ({ headers, rows, actionButtons, onActionClick, headerStyles }) => {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("");
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (_, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const sortedRows = rows.sort((a, b) => {
    if (orderBy) {
      return order === "asc" ? (a[orderBy] < b[orderBy] ? -1 : 1) : a[orderBy] < b[orderBy] ? 1 : -1;
    }
    return 0;
  });

  const displayedRows = sortedRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Paper elevation={2} style={{ borderRadius: "8px", overflow: "hidden" }}>
      <StyledTableContainer>
        <StyledTable stickyHeader>
          <StyledTableHead headerStyles={headerStyles}>
            <TableRow>
              {headers.map((header) => (
                <StyledTableCell 
                  key={header.key} 
                  onClick={() => handleRequestSort(header.key)} 
                  style={{ cursor: "pointer" }}
                  headerStyles={headerStyles}
                >
                  {header.label}
                </StyledTableCell>
              ))}
              <StyledTableCell style={{ textAlign: "center" }} headerStyles={headerStyles}>
                Actions
              </StyledTableCell>
            </TableRow>
          </StyledTableHead>
          <TableBody>
            {displayedRows.map((row, index) => (
              <TableRow hover key={index}>
                {headers.map((header) => (
                  <StyledBodyCell key={header.key}>
                    {header.key.includes(".")
                      ? header.key.split(".").reduce((obj, key) => obj?.[key], row) // Handle nested keys
                      : row[header.key]}
                  </StyledBodyCell>
                ))}
                <ActionsColumn>
                  {actionButtons.map((action, idx) => (
                    <IconButton key={idx} onClick={() => onActionClick(action, row)} color={action.color || "primary"} sx={{ mx: 0.5 }}>
                      {action.icon}
                    </IconButton>
                  ))}
                </ActionsColumn>
              </TableRow>
            ))}
          </TableBody>
        </StyledTable>
      </StyledTableContainer>
      <PaginationContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </PaginationContainer>
    </Paper>
  );
};

// Wrap with ThemeProvider
const WrappedCommonTable = (props) => {
  const theme = createTheme();
  return (
    <ThemeProvider theme={theme}>
      <CommonTable {...props} />
    </ThemeProvider>
  );
};

export default WrappedCommonTable;
