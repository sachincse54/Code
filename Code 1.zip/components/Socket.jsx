import React from 'react';
import useWebSocket from 'react-use-websocket';

function Socket() {
  const WS_URL = 'ws://localhost:3000';

  const {
    sendMessage,
    lastMessage,
    readyState,
  } = useWebSocket(WS_URL, {
    onOpen: () => console.log('WebSocket connection opened'),
    onClose: () => console.log('WebSocket connection closed'),
    onError: (error) => console.error('WebSocket error:', error),
    // Attempt to reconnect on connection loss
    shouldReconnect: (closeEvent) => true,
    reconnectAttempts: 10,
    reconnectInterval: 2000,
  });

  // Parse the last message received into users array
  const users = lastMessage ? JSON.parse(lastMessage.data) : [];

  // Map readyState to human-readable status
  const connectionStatus = {
    0: 'Connecting',
    1: 'Connected',
    2: 'Closing',
    3: 'Disconnected',
  }[readyState];

  return (
    <div className="App">
      <h1>User List (WebSocket Demo)</h1>
      <p>Connection Status: {connectionStatus}</p>
      
      {users.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Age</th>
              <th>City</th>
              <th>Username</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td>{user.age}</td>
                <td>{user.city}</td>
                <td>{user.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Waiting for data...</p>
      )}
    </div>
  );
}

export default Socket;